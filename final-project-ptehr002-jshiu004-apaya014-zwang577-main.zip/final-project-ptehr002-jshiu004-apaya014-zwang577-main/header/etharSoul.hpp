#ifndef ETHAR_SOUL_HPP
#define ETHAR_SOUL_HPP
#include "userCharacter.hpp"
#include "enemyCharacter.hpp"

class etharSoul: public EnemyCharacter{
    public:
        etharSoul();
        ~etharSoul();
        // void Agony(UserCharacter& userChar);
        
};





#endif