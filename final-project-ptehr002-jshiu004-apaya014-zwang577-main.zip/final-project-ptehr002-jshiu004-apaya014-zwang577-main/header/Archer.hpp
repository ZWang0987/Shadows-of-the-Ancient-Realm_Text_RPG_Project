// #ifndef ARCHER_HPP
// #define ARCHER_HPP
// #include "userCharacter.hpp"
// #include "enemyCharacter.hpp"

// class Archer: public UserCharacter{
//     public:
//         Archer(const string& userName);
//         void explosvieBolt(EnemyCharacter& enemyChar);
//         void piercingArrow(EnemyCharacter& enemyChar);
//         void Volley(EnemyCharacter& enemyChar);
//         void arcaneShot(EnemyCharacter& enemyChar);
// };





// #endif