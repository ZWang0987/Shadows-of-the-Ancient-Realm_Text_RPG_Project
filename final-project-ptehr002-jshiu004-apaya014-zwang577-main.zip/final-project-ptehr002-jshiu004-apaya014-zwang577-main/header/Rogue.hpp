// #ifndef ROGUE_HPP
// #define ROGUE_HPP
// #include "userCharacter.hpp"
// #include "enemyCharacter.hpp"


// class Rogue : public UserCharacter {
//     private: 
//         string className;
//     public:
//         Rogue(const string& userName);
//         void sneakyDagger(EnemyCharacter& enemyChar);
//         void shadowStep(EnemyCharacter& enemyChar);
//         void sinisterSlash(EnemyCharacter& enemyChar);
//         void eviserate(EnemyCharacter& enemyChar);

// };







// #endif