#ifndef DIALLOS_HPP
#define DIALLOS_HPP
#include "userCharacter.hpp"
#include "enemyCharacter.hpp"

class Diallos: public EnemyCharacter{
    public:
        Diallos();
        ~Diallos();
        // void Hellfire(UserCharacter& userChar);
        // void nullSphere(UserCharacter& userChar);
        // void blackDeath(UserCharacter& userChar);
        // void riftWalk(UserCharacter& userChar);
        
};





#endif