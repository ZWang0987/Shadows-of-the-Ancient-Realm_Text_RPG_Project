// #ifndef Knight_HPP
// #define KNIGHT_HPP
// #include "userCharacter.hpp"
// #include "enemyCharacter.hpp"


// class Knight : public UserCharacter {
//     public:
//         Knight(const string& userName);
//         void slash(EnemyCharacter& enemyChar);
//         void shieldSlam(EnemyCharacter& enemyChar);
//         void whirlwind(EnemyCharacter& enemyChar);
//         void thunderClap(EnemyCharacter& enemyChar);
// };



// #endif