#ifndef RAGNAR_HPP
#define RAGNAR
#include "userCharacter.hpp"
#include "enemyCharacter.hpp"

class Ragnar : public EnemyCharacter {
    public:
        Ragnar();
        ~Ragnar();
        // void overheat(UserCharacter& userChar);
        // void pyroclasm(UserCharacter& userChar);
        // void flamethrower(UserCharacter& userChar);
        // void fireSlam(UserCharacter& userChar);

};



#endif