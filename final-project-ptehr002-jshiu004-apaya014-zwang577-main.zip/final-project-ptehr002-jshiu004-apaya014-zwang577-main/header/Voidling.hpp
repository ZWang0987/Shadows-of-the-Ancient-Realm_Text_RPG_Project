#ifndef VOIDLING_HPP
#define VOIDLING
#include "userCharacter.hpp"
#include "enemyCharacter.hpp"

class Voidling : public EnemyCharacter {
    public:
        Voidling();
        ~Voidling();
        // void voidBite(UserCharacter& userChar);
        
        

};



#endif