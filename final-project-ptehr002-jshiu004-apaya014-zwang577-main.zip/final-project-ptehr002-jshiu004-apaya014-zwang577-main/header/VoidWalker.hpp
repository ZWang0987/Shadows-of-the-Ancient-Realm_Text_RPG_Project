#ifndef VOIDWALKER_HPP
#define VOIDWALKER
#include "userCharacter.hpp"
#include "enemyCharacter.hpp"

class VoidWalker : public EnemyCharacter {
    public:
        VoidWalker();
        ~VoidWalker();
        // void corruption(UserCharacter& userChar);
        // void energyDrain(UserCharacter& userChar);
        
        

};



#endif