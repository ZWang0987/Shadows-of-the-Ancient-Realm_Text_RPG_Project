#ifndef KAISON_HPP
#define KAISON_HPP
#include "userCharacter.hpp"
#include "enemyCharacter.hpp"

class KaiSon: public EnemyCharacter{
    public:
        KaiSon();
        ~KaiSon();
        // void voidSeaker(UserCharacter& userChar);
        // void voidRain(UserCharacter& userChar);
        // void voidShift(UserCharacter& userChar);
        // void voidSurge(UserCharacter& userChar);
        
};





#endif