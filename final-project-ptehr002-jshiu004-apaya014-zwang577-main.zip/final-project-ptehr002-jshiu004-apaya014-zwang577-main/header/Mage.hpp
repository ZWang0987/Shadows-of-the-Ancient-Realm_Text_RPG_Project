// #ifndef MAGE_HPP
// #define MAGE_HPP
// #include "userCharacter.hpp"
// #include "enemyCharacter.hpp"

// class Mage: public UserCharacter{
//     private:
//         string className;
//     public:
//         Mage(const string& userName);
//         void fireBall(EnemyCharacter& enemyChar);
//         void frostBolt(EnemyCharacter& enemyChar);
//         void arcaneBlast(EnemyCharacter& enemyChar);
//         void elementalStrike(EnemyCharacter& enemyChar);

// };





// #endif