#ifndef DELLIO_HPP
#define DELLIO_HPP
#include "userCharacter.hpp"
#include "enemyCharacter.hpp"

class Dellio : public EnemyCharacter {
    public:
        Dellio();
        ~Dellio();
        // void netherBlade(UserCharacter& userChar);
        // void inferno(UserCharacter& userChar);
        // void rainOfFire(UserCharacter& userChar);
        // void blazingDeath(UserCharacter& userChar);

};



#endif
