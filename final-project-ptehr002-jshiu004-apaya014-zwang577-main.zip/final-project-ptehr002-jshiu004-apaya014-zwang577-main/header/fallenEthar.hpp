#ifndef FALLEN_ETHAR_HPP
#define FALLEN_ETHAR_HPP
#include "userCharacter.hpp"
#include "enemyCharacter.hpp"

class fallenEthar: public EnemyCharacter{
    public:
        fallenEthar();
        ~fallenEthar();
        // void lightStrike(UserCharacter& userChar);
        // void darkStrike(UserCharacter& userChar);
        
};





#endif