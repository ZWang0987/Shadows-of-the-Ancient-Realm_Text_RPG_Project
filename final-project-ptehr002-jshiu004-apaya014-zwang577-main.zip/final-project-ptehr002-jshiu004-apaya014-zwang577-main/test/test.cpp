#include "gtest/gtest.h"
#include "../src/SpireDriver.cpp"
#include "../src/storyDriver.cpp"

TEST(spireTests, shopTest) {
    UserCharacter* hero = new UserCharacter("player", "Knight", 100, 6, 1, 6, 1, 100, 0);
    SpireDriver<UserCharacter>* start = new SpireDriver<UserCharacter>(hero);
    start->printUserInventory();
    start->vendorRoom();
    start->printUserInventory();
    EXPECT_TRUE(hero->getGold() < 100);
}

TEST(spireTests, loreRoomTest) {
    UserCharacter* hero = new UserCharacter("player", "Knight", 100, 6, 1, 6, 1, 100, 0);
    SpireDriver<UserCharacter>* start = new SpireDriver<UserCharacter>(hero);
    start->loreRoom();
    EXPECT_TRUE(visits > 1);
}

TEST(spireTests, basicCombatTest) {
    UserCharacter* hero = new UserCharacter("player", "Knight", 100, 6, 1, 6, 1, 100, 0);
    SpireDriver<UserCharacter>* start = new SpireDriver<UserCharacter>(hero);
    start->printUserStats();
    start->basicCombatEncounter();
    start->printUserStats();
    EXPECT_TRUE(hero->getHealth() < 100);
}

TEST(spireTests, miniBossCombatTest) {
    UserCharacter* hero = new UserCharacter("player", "Knight", 100, 124, 1, 6, 1, 100, 0);
    SpireDriver<UserCharacter>* start = new SpireDriver<UserCharacter>(hero);
    start->setSpireLevel(10);
    start->printUserStats();
    start->miniBossRoom();
    start->printUserStats();
    int health = hero->getHealth();
    delete hero;
    EXPECT_TRUE(health < 100);

}

TEST(spireTests, BossCombatTest) {
    UserCharacter* hero = new UserCharacter("player", "Knight", 100, 190, 1, 6, 1, 100, 0);
    SpireDriver<UserCharacter>* start = new SpireDriver<UserCharacter>(hero);
    start->setSpireLevel(25);
    start->printUserStats();
    start->finalBossRoom();
    start->printUserStats();
    EXPECT_TRUE(hero->getHealth() < 100);
}

TEST(spireTests, restingRoomTest) {
    UserCharacter* hero = new UserCharacter("player", "Knight", 80, 6, 1, 6, 1, 100, 0);
    SpireDriver<UserCharacter>* start = new SpireDriver<UserCharacter>(hero);
    start->printUserStats();
    start->restingRoom();
    start->printUserStats();
    EXPECT_TRUE(hero->getHealth() > 80);
}

TEST(spireTests, lootRoomTest) {
    UserCharacter* hero = new UserCharacter("player", "Knight", 100, 0, 0, 0, 0, 0, 0);
    SpireDriver<UserCharacter>* start = new SpireDriver<UserCharacter>(hero);
    start->lootRoom();
    EXPECT_TRUE(hero->getHealth() > 100 || hero->getStrength() > 0 || hero->getDefense() > 0 || hero->getWisdom() > 0 || hero->getSpeed() > 0);
}

TEST(spireTests, spireLevelsTest) {
    UserCharacter* hero = new UserCharacter("player", "Knight", 100, 0, 0, 0, 0, 0, 0);
    SpireDriver<UserCharacter>* start = new SpireDriver<UserCharacter>(hero);
    vector<int> rooms = start->printNextSpireLevelOption();
    EXPECT_TRUE(rooms.size() > 0);
}


TEST(userCharacterTests,KnightCreationPass) {
    UserCharacter* knight = nullptr;
    knight = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    EXPECT_TRUE(knight->getClassName() == "Knight");
}

TEST(userCharacterTests,AppendDefense) {
    UserCharacter* knight = nullptr;
    knight = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    knight->appendDefense(5);
    EXPECT_TRUE(knight->getDefense() == 11 );
}

TEST(userCharacterTests,AppendXP) {
    UserCharacter* knight = nullptr;
    knight = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    knight->appendXP(10);
    EXPECT_TRUE(knight->getXp() == 10);
}

TEST(userCharacterTests,AppendMaxHealth) {
    UserCharacter* knight = nullptr;
    knight = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    knight->appendMaxHealth(10);
    EXPECT_TRUE(knight->getMaxHealth() == 110);
}

TEST(userCharacterTests,AppendGold) {
    UserCharacter* knight = nullptr;
    knight = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    knight->appendGold(10);
    EXPECT_TRUE(knight->getGold() == 10);
}

TEST(userCharacterTests,GetLevel) {
    UserCharacter* knight = nullptr;
    knight = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    int level = knight->getLevel();
    EXPECT_TRUE(level == 1);
}

TEST(userCharacterTests,LevelUp) {
    UserCharacter* knight = nullptr;
    knight = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    knight->appendXP(100);
    knight->levelUp();
    EXPECT_TRUE(knight->getLevel() == 2);
}

TEST(userCharacterTests,Items) {
    UserCharacter* knight = nullptr;
    knight = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    
    knight->addItem("Strength buff");
    knight->useItem();

    EXPECT_TRUE(knight->getStrength() > 6);
}


TEST(storyTests,caveItemSelectPass) {
    UserCharacter* userChar = nullptr;
    userChar = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    StoryDriver<UserCharacter>* story= new StoryDriver<UserCharacter>(userChar);
    story->caveItemSelection();
    EXPECT_TRUE(userChar->getStrength() > 6);
}

TEST(storyTests,TestCaveBattle) {
    UserCharacter* userChar = nullptr;
    userChar = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    StoryDriver<UserCharacter>* story= new StoryDriver<UserCharacter>(userChar);
    story->CaveBattle();
    EXPECT_TRUE(userChar->getHealth() < 100);
}

TEST(storyTests,TestGetResponse) {
    UserCharacter* userChar = nullptr;
    userChar = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    StoryDriver<UserCharacter>* story= new StoryDriver<UserCharacter>(userChar);
    int input = story->getResponse();
    EXPECT_TRUE(input == 1 or input == 2);
}

TEST(storyTests,TestContinueStory) {
    UserCharacter* userChar = nullptr;
    userChar = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    StoryDriver<UserCharacter>* story= new StoryDriver<UserCharacter>(userChar);
    int input = story->continueStory();
    EXPECT_TRUE(input == 1);
}

TEST(storyTests,TestFinishStory) {
    UserCharacter* userChar = nullptr;
    userChar = new UserCharacter("userName", "Knight", 100, 6, 1, 6, 1, 0, 0);
    StoryDriver<UserCharacter>* story= new StoryDriver<UserCharacter>(userChar);
    story->startStory();
    EXPECT_TRUE(userChar->getStrength() > 6);
}

TEST(EnemyTests, appendDroppedXPTest) {
    EnemyCharacter* opp = new EnemyCharacter("roger", "123", 100, 20, 20, 20, 20, 20, 20);
    opp->appendDroppedXp(5);
    EXPECT_EQ(opp->getDroppedXp(), 25);
}

TEST(EnemyTests, appendDroppedGoldTest) {
    EnemyCharacter* opp = new EnemyCharacter("roger", "123", 100, 20, 20, 20, 20, 20, 20);
    opp->appendDroppedGold(5);
    EXPECT_EQ(opp->getDroppedGold(), 25);
}

TEST(EnemyTests, getRankTest) {
    EnemyCharacter* opp = new EnemyCharacter("roger", "123", 100, 20, 20, 20, 20, 20, 20);
    EXPECT_EQ(opp->getEnemyRank(), "123");
}

TEST(CharacterTests, appendHealthTest) {
    Character* hero = new Character("bro", 100, 15, 15, 15, 15);
    hero->appendCurrentHealth(5);
    EXPECT_DOUBLE_EQ(hero->getHealth(), 105);
}
TEST(CharacterTests, appendStrengthTest) {
    Character* hero = new Character("bro", 100, 15, 15, 15, 15);
    hero->appendStrength(5);
    EXPECT_DOUBLE_EQ(hero->getStrength(), 20);
}
TEST(CharacterTests, appendSpeedTest) {
    Character* hero = new Character("bro", 100, 15, 15, 15, 15);
    hero->appendSpeed(5);
    EXPECT_DOUBLE_EQ(hero->getSpeed(), 20);
}
TEST(CharacterTests, appendWisdomTest) {
    Character* hero = new Character("bro", 100, 15, 15, 15, 15);
    hero->appendWisdom(5);
    EXPECT_DOUBLE_EQ(hero->getWisdom(), 20);
}
TEST(CharacterTests, appendDefenseTest) {
    Character* hero = new Character("bro", 100, 15, 15, 15, 15);
    hero->appendDefense(5);
    EXPECT_DOUBLE_EQ(hero->getDefense(), 20);
}

TEST(BattleDriverTests, RogueTester) {
    UserCharacter* hero = new UserCharacter("userName", "Rogue", 100, 20, 1, 1, 6, 0, 0);
    etharSoul* opponent = new etharSoul();
    BattleDriver<etharSoul>* battle = new BattleDriver<etharSoul>(hero, opponent);
    battle->startBattle();
    delete opponent;
    EXPECT_TRUE(hero->getHealth() < 100);
}

TEST(BattleDriverTests, MageTester) {
    UserCharacter* hero = new UserCharacter("userName", "Mage", 100, 90, 10, 1, 1, 0 , 0);
    KaiSon* opponent = new KaiSon();
    BattleDriver<KaiSon>* battle = new BattleDriver<KaiSon>(hero, opponent);
    battle->startBattle();
    delete opponent;
    EXPECT_TRUE(hero->getHealth() < 100);
}

TEST(BattleDriverTests, ArcherTester) {
    UserCharacter* hero = new UserCharacter("userName", "Archer", 100, 170, 2, 1, 5, 0 , 0);
    Dellio* opponent = new Dellio();
    BattleDriver<Dellio>* battle = new BattleDriver<Dellio>(hero, opponent);
    battle->startBattle();
    delete opponent;
    EXPECT_TRUE(hero->getHealth() < 100);
}

TEST(BattleDriverTests, fallenEtharTester) {
    UserCharacter* hero = new UserCharacter("userName", "Archer", 100, 40, 2, 1, 5, 0 , 0);
    fallenEthar* opponent = new fallenEthar();
    BattleDriver<fallenEthar>* battle = new BattleDriver<fallenEthar>(hero, opponent);
    battle->startBattle();
    delete opponent;
    EXPECT_TRUE(hero->getHealth() < 100);
}